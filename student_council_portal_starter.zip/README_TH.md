# ระบบสภานักเรียน — คู่มือติดตั้งออนไลน์ (Firebase + ฟรี)

เว็บตัวเริ่มต้นธีมเขียว–เหลือง พร้อมโลโก้ 2 ภาพที่ได้รับมา, ล็อกอิน, หน้าสรุป, ฟอร์มบันทึกเวร/คะแนน/กิจกรรม และโครงเชื่อม Firestore แบบเรียลไทม์

## ก่อนใช้งานจริง
ไฟล์นี้เป็น starter project ไม่ใช่เว็บไซต์ที่เผยแพร่แล้ว และยังไม่มีฐานข้อมูลของโรงเรียน ต้องตั้งค่า Firebase และกำหนดบทบาทจากฝั่งผู้ดูแลที่เชื่อถือได้ก่อน ห้ามใส่รหัสผ่านแอดมินในโค้ดหน้าเว็บ

## เริ่มต้น Firebase
1. ไปที่ https://console.firebase.google.com/ แล้วกด **Create a project** ตั้งชื่อโครงการ
2. เข้า **Build → Authentication → Get started** เปิด Email/Password
3. เข้า **Build → Firestore Database → Create database** เลือก production mode และ region ใกล้ประเทศไทย
4. Project settings → General → Your apps → Web (</>) → Register app แล้วคัดลอกค่าการตั้งค่า
5. คัดลอก `.env.example` เป็น `.env` แล้วใส่ค่าจริงจาก Firebase
6. เปิด Authentication → Settings → Authorized domains และเพิ่มโดเมนที่ใช้เผยแพร่
7. วางกฎจาก `firestore.rules` ใน Firestore → Rules แล้วกด Publish

## กำหนดบทบาทอย่างปลอดภัย
กฎนี้อ่านบทบาทจาก Firebase **custom claims** ได้แก่ `role` และสำหรับนักเรียน `classRoom` ไม่ใช่จากช่องที่ผู้ใช้แก้เองได้ในหน้าเว็บ จึงต้องตั้งค่าโดย Admin SDK ในสภาพแวดล้อมที่เชื่อถือได้ เช่น Cloud Functions/เครื่องผู้ดูแลที่เก็บ service account อย่างปลอดภัย
- `president` = ประธานนักเรียน: เพิ่มนักเรียน/ห้อง/เขตพื้นที่ บันทึกคะแนนและกิจกรรม อนุมัติข้อมูล จัดการระบบ
- `inspector` = ผู้ตรวจ: ตรวจและลงชื่อผ่านขั้นตอนที่โรงเรียนกำหนด แต่ไม่มี Dashboard และไม่มีสิทธิ์เขียนข้อมูลหลักในกฎตัวอย่างนี้ (หากต้องการให้ผู้ตรวจลงชื่อ ต้องเพิ่ม collection/signature และ rule แบบจำกัดฟิลด์)
- `student` = นักเรียน: ดูได้เฉพาะข้อมูลตัวเองและคะแนน/ข้อมูลของห้องตัวเองตาม query ที่สอดคล้องกับกฎ

อย่าตั้ง role จากค่าที่ส่งมาจาก browser และอย่าเปิด Firestore เป็น `allow read, write: if true`.

## รันในเครื่อง
ติดตั้ง Node.js LTS จาก https://nodejs.org/
```bash
npm install
cp .env.example .env
npm run dev
```
เปิด URL ที่ Vite แสดงใน terminal

## เผยแพร่ฟรีด้วย Firebase Hosting
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
```
เลือกโปรเจกต์ Firebase ที่สร้างไว้, ใช้ `dist` เป็น public directory, เลือก single-page app = Yes จากนั้น:
```bash
npm run build
firebase deploy
```
Firebase จะแสดง URL สำหรับแชร์กับโรงเรียน (รูปแบบ `https://ชื่อโปรเจกต์.web.app`) หลัง deploy สำเร็จ

## ข้อมูลสำคัญ
- การซิงก์ข้ามเครื่องเกิดขึ้นเมื่อทุกเครื่องใช้โปรเจกต์ Firebase เดียวกันและออนไลน์
- การเปลี่ยนรหัสผ่านใช้ Firebase Authentication (เพิ่มหน้า reset password ได้)
- ก่อนใช้จริง ให้ทดสอบกฎด้วย Firebase Emulator/Rules Playground และให้ผู้ดูแลโรงเรียนตรวจความเหมาะสม
- ยังต้องต่อการอ่าน/เขียนข้อมูลจริงในหน้าฟอร์ม และสร้างกระบวนการอนุมัติประธาน/ผู้ตรวจให้ครบก่อนใช้กับข้อมูลนักเรียนจริง
